﻿namespace filter_num
{
    class Program
    {
        public void Main()
        {
            static int[] Filter(int[] Array, int[] Array_2)
            {          
                HashSet<int> originalSet = new HashSet<int>(Array);
                HashSet<int> filterSet = new HashSet<int>(Array_2);              
                int[] filteredArray = new int[Array.Length - filterSet.Count];                
                int index = 0;
                foreach (int element in Array)
                {
               
                    if (!filterSet.Contains(element))
                    {
                        filteredArray[index++] = element;
                    }
                }
                return filteredArray;
            }
        }
    }
}
