﻿
#include <iostream>
#include <algorithm> 

using namespace std;

int main() {
    setlocale(LC_ALL, "UK");

    cout << "Меню" << endl;
    cout << "_______________________________________________________" << endl;
    cout << "1|Заповнення масиву випадковими значеннями" << endl;
    cout << "2|Виведення значень масиву на консоль" << endl;
    cout << "3|Пошуку мінімального елемента" << endl;
    cout << "4|Пошуку максимального елемента" << endl;
    cout << "5|Сортування масиву" << endl;
    cout << "6|Редагування значення масиву" << endl;
    cout << "7|Вихід" << endl;
    cout << "_______________________________________________________" << endl;

    int choice; 
    cin >> choice;

    switch (choice) {
    case 1: {
        int arr[10];
        int i;
        srand(time(0));

        for (i = 0; i < 10; i++) {
            arr[i] = 1 + rand() % 9;
        }

        cout << "[" << " ";
        for (i = 0; i < 10; i++) {
            cout << arr[i] << " ";
        }
        cout << "]";
        break;
    }
    case 2: {
        int arr[10]; 
        int i;

        cout << "Введіть 10 чисел для заповнення масиву: " << endl;
        for (i = 0; i < 10; i++) {
            cin >> arr[i];
        }

        cout << "Масив: [ ";
        for (i = 0; i < 10; i++) {
            cout << arr[i] << " ";
        }
        cout << "]" << endl;
        break;
    }
    case 3: {
        int arr[10];
        int i;

        cout << "Введіть 10 чисел для заповнення масиву: " << endl;
        for (i = 0; i < 10; i++) {
            cin >> arr[i];
        }

        int min_element = *min_element(arr, arr + 10); 
        cout << "Мінімальний елемент: " << min_element << endl;
        break;
    }
    case 4: {
        int arr[10]; 
        int i;

        cout << "Введіть 10 чисел для заповнення масиву: " << endl;
        for (i = 0; i < 10; i++) {
            cin >> arr[i];
        }

        int max_element = *max_element(arr, arr + 10); 
        cout << "Максимальний елемент: " << max_element << endl;
        break;
    }
    case 5: {
        int arr[10]; 
        int i;

        cout << "Введіть 10 чисел для заповнення масиву: " << endl;
        for (i = 0; i < 10; i++) {
            cin >> arr[i];
        }

        sort(arr, arr + 10); 
        cout << "Відсортований масив: [ ";
        for (i = 0; i < 10; i++) {
            cout << arr[i] << " ";
        }
        cout << "]" << endl;
        break;
    }
    case 6: {
        int arr[10]; 
        int i;

        cout << "Введіть 10 чисел для заповнення масиву: " << endl;
        for (i = 0; i < 10; i++) {
            cin >> arr[i];
        }

        int index;
    case 7:
    {
        break;
    }