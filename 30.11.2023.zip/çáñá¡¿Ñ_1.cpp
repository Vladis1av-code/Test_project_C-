﻿#include <iostream>
using namespace std;
template <typename T>
class List {
public:
    // Конструктор
    List() : head(nullptr), tail(nullptr) {}

    ~List() {
        while (head) {
            Node* temp = head;
            head = head->next;
            delete temp;
        }
    }

   
    bool isEmpty() const {
        return head == nullptr;
    }

  
    void pushBack(const T& value) {
        Node* newNode = new Node(value);
        if (isEmpty()) {
            head = tail = newNode;
        }
        else {
            tail->next = newNode;
            tail = newNode;
        }
    }

 
    void pushFront(const T& value) {
        Node* newNode = new Node(value);
        newNode->next = head;
        head = newNode;
        if (tail == nullptr) {
            tail = newNode;
        }
    }

 
    T popBack() {
        if (isEmpty()) {
            throw std::runtime_error("Список пустий!");
        }

        T value = tail->value;
        Node* temp = tail;
        tail = tail->prev;
        if (tail == nullptr) {
            head = nullptr;
        }
        else {
            tail->next = nullptr;
        }
        delete temp;

        return value;
    }

   
    T popFront() {
        if (isEmpty()) {
            throw std::runtime_error("Список пустий!");
        }

        T value = head->value;
        Node* temp = head;
        head = head->next;
        if (head == nullptr) {
            tail = nullptr;
        }
        delete temp;

        return value;
    }

    // виртуальное добавление
    virtual void insert(const T& value) = 0;

    // виртуальное удаление
    virtual T remove() = 0;

private:
    
    struct Node {
        T value;
        Node* prev;
        Node* next;

        Node(const T& value, Node* prev = nullptr, Node* next = nullptr)
            : value(value), prev(prev), next(next) {}
    };

    Node* head; 
    Node* tail; 
};

class Stack : public List<T> {
public:
    void insert(const T& value) override {
        pushFront(value); // Добавляет елементы в начало
    }


    T remove() override {
        if (isEmpty()) {
            throw std::runtime_error("Стек пустий!");
        }

        T value = popFront(); // Удаляет елементы с начало
        return value;
    }
};

int main() {
    setlocale(LC_ALL, "ru");
    Stack<int> stack;

    stack.pushFront(1);
    stack.pushFront(2);
    stack.pushFront(3);

    cout << "Стек:\n";
    while (!stack.isEmpty()) {
        std::cout << stack.remove() << " ";
    }

    return 0;
}
