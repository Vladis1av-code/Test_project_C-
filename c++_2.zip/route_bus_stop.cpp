﻿

#include <iostream>
#include <random>
#include <vector>

using namespace std;
struct pass {
    double Time_stop;
};
struct transport
{
    int Seats;
    double Time_stop;
};
int main()
{
    setlocale(LC_ALL, "ru");
    double avgPassengerInterval[24] = {12,3}; // Середній час між появою пасажирів у різний час доби
    double avgBusInterval[24] = {12,5}; // Середній час між появою маршруток у різний час доби
    bool isFinalStop = {}; // Тип зупинки (кінцева чи ні)
    int maxPeopleAtStop = {35}; // Максимальна кількість людей на зупинці
    int minFreeSeats = {}; // Мінімальна кількість вільних місць у маршрутці
    int maxFreeSeats = {}; // Максимальна кількість вільних місць у маршрутці
    double simulationTime = {}; // Проміжок часу для імітації

    
    random_device rd;
    mt19937 gen(rd());
    uniform_real_distribution<> dis_passenger(0.0, avgPassengerInterval[0]); 
    uniform_real_distribution<> dis_bus(0.0, avgBusInterval[0]); 
    uniform_int_distribution<> dis_seats(minFreeSeats, maxFreeSeats);

    
    vector<Passenger> passengers; 
    vector<Time_stop> buses; 
    double waitingTime = 0.0; 
    double currentTime = 0.0; 
    int peopleAtStop = 0; 
    int totalWaitingTime = 0;

    while (currentTime < simulationTime) {
        
        double nextPassengerTime = dis_passenger(gen);

      
        double nextBusTime = dis_bus(gen);

      
        if (nextPassengerTime < nextBusTime) {
        
            currentTime += nextPassengerTime;
            passengers.push_back({ currentTime });
            peopleAtStop++;

         
            if (peopleAtStop > maxPeopleAtStop) {
                cout << "Error" << endl;
                break;
            }

           
            waitingTime += peopleAtStop * (nextBusTime - currentTime);
            totalWaitingTime += waitingTime;
        }
        else {
           
            currentTime += nextBusTime;
            while (peopleAtStop > 0 && buses.back().freeSeats > 0) {
                passengers.pop_back();
                peopleAtStop--;

                
                int availableSeats = min(buses.back().freeSeats, buses.back().capacity);
                buses.back().freeSeats -= availableSeats;
            }

            while (peopleAtStop > 0 && buses.back().freeSeats > 0) {
                passengers.pop_back();
                peopleAtStop--;
                buses.back().freeSeats--;
            }

          
            if (peopleAtStop > 0) {
                waitingTime += peopleAtStop * (simulationTime - currentTime);
                totalWaitingTime += waitingTime;
            }
        }
    }

   
    double averageWaitingTime = totalWaitingTime / passengers.size();
    cout << "Время ожидания: " << averageWaitingTime << endl;


    return 0;
}


