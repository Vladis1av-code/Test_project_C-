﻿#include <cstring>
#include <iostream>

class String {
protected:
    char* str;
    size_t length;

public:
    // Конструктор без параметрів
    String() : str(new char[1]), length(0) {
        str[0] = '0';
    }

    // Конструктор, що приймає C-рядок
    String(const char* s) : length(strlen(s)) {
        str = new char[length + 1];
        strcpy(str, s);
    }

    // Конструктор копіювання
    String(const String& other) : length(other.length) {
        str = new char[length + 1];
        strcpy(str, other.str);
    }

    // Оператор присвоєння
    String& operator=(const String& other) {
        if (this != &other) {
            delete[] str;
            length = other.length;
            str = new char[length + 1];
            strcpy(str, other.str);
        }
        return *this;
    }

    // Отримання довжини рядка
    size_t getLength() const {
        return length;
    }

    // Очищення рядка
    void clear() {
        delete[] str;
        str = new char[1];
        str[0] = '0';
        length = 0;
    }

    // Деструктор
    virtual ~String() {
        delete[] str;
    }

    // Конкатенація рядків
    String operator+(const String& other) const {
        String result;
        result.length = length + other.length;
        result.str = new char[result.length + 1];
        strcpy(result.str, str);
        strcat(result.str, other.str);
        return result;
    }

    String& operator+=(const String& other) {
        char* newStr = new char[length + other.length + 1];
        strcpy(newStr, str);
        strcat(newStr, other.str);
        delete[] str;
        str = newStr;
        length += other.length;
        return *this;
    }

    // Перевірка на рівність і нерівність
    bool operator==(const String& other) const {
        return strcmp(str, other.str) == 0;
    }

    bool operator!=(const String& other) const {
        return !(*this == other);
    }
};

class BitString : public String {
public:
    // Конструктор без параметрів
    BitString() : String() {}

    // Конструктор, що приймає C-рядок
    BitString(const char* s) : String(s) {
        for (size_t i = 0; i < length; ++i) {
            if (str[i] != '0' && str[i] != '1') {
                clear();
                break;
            }
        }
    }

    // Конструктор копіювання
    BitString(const BitString& other) : String(other) {}

    // Оператор присвоєння
    BitString& operator=(const BitString& other) {
        String::operator=(other);
        return *this;
    }

    // Деструктор
    ~BitString() {}

    // Зміна знаку числа
    void negate() {
        // Ваша реалізація зміни знаку числа
    }

    // Складання бітових рядків
    BitString operator+(const BitString& other) const {
        // Ваша реалізація складання бітових рядків
    }

    BitString& operator+=(const BitString& other) {
        // Ваша реалізація складання бітових рядків
    }

    // Перевірка на рівність і нерівність
    bool operator==(const BitString& other) const {
        return String::operator==(other);
    }

    bool operator!=(const BitString& other) const {
        return String::operator!=(other);
    }
};
