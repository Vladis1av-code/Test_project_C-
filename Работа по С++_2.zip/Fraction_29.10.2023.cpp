﻿
#include <iostream>
using namespace std;

class Fraction
{
private:
    int a;
    int b;
public:
    Fraction(int a, int b)
    {
        this->a = a;
        this->b = b;
    }
    //отримання чисельника
    int num_a() const 
    {return a;}
    //та знаменника
    int num_b() const
    {return b;}

    int print() const {
        cout << a << "/" << b;
    }

    //Перевантаження операторів 
    Fraction operator+(const Fraction& other)const {
        int new_a = a * other.b + b * other.a;//перевантаження чисельника в перевантаження оператора +
        int new_b = b * other.a + a * other.b;
        return Fraction(new_a, new_b);
    }

    Fraction operator/(const Fraction& other)const {
        int new_a = a * other.b / b * other.a;//перевантаження чисельника в перевантаження оператора /
        int new_b = b * other.a / a * other.b;
        return Fraction(new_a, new_b);
    }

    Fraction operator-(const Fraction& other)const {
        int new_a = a * other.b - b * other.a;//перевантаження чисельника в перевантаження оператора -
        int new_b = b * other.a - a * other.b;
        return Fraction(new_a, new_b);
    }

    Fraction operator*(const Fraction& other)const {
        int new_a = a * other.b * b * other.a;//перевантаження чисельника в перевантаження оператора *
        int new_b = b * other.a * a * other.b;
        return Fraction(new_a, new_b);
    }
};


int main()
{
    setlocale(LC_ALL, "ru");
    int number_1;
    int number_2;
    int number_3;
    int number_4;
    cout << "_______________________________________________________" << endl;
    cout << "Введите первое число:" << endl;
    cin >> number_1;
    cout << "Введите второе число:" << endl;
    cin  >> number_2;
    cout << "Введите третье число:" << endl;
    cin  >> number_3;
    cout << "Введите четвертое число:" << endl;
    cin  >> number_4;
    cout << "_______________________________________________________" << endl;
    Fraction num(number_1, number_2);
    Fraction num2(number_3, number_4);

    cout << "Первая дробь" <<endl;
    num.print();

    cout << "Вторая дробь" << endl;
    num2.print();

    cout << "Умножение num * num2:" << endl;
    (num*num2).print();

    cout << "Деление num / num2:" << endl;
    (num/num2).print();

    cout << "Сумма num + num2:" << endl;
    (num + num2).print();

    cout << "Вычитание num-num2:" << endl;
    (num - num2).print();

    return 0;
}

