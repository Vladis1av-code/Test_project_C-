﻿#include <iostream>
#include <fstream>
#include <vector>
using namespace std;
int main()
{
    //1
   /* const int rows = 3, columns = 2;
    int numbers[rows][columns]{ {1, 2}, {3, 4}, {5, 6} };
       for (int i = 0; i < rows; i++)
       {
           for (int j = 0; j < columns; j++)
           {
               cout << numbers[i][j] << "\t";
           }
           cout << endl;
       }
       cout<< endl;
       for (int i = 0; i < columns; i++)
       {
           for (int j = 0; j < rows; j++)
           {
               cout << " " << numbers[j][i];
           }
           cout << endl;
       }*/


       //2
    
  /*  vector<vector<string>> data;
    string name, phone_num;
    while (true) {
        cout << "Введите имя: ";
        cin >> name;
        cout << "Введите номер телефону: ";
        cin >> phone_num;
        data.push_back({ name, phone_num });
        char c;
        cout << "Продолжить? (y/n): ";
        cin >> c;
        if (c != 'y') {
            break;
        }
    }
    string searchName;
    cout << "Введите имя для поиска: ";
    cin >> searchName;
    bool found = false;
    for (int i = 0; i < data.size(); i++) {
        if (data[i][0] == searchName) {
            cout << "Найшло: " << data[i][0] << ", " << data[i][1] << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Имя не найдено." << endl;
    }
    string searchPhone;
    cout << "Введите номер телефону для поиска: ";
    cin >> searchPhone;
    found = false;
    for (int i = 0; i < data.size(); i++) {
        if (data[i][1] == searchPhone) {
            cout << "Найшло: " << data[i][0] << ", " << data[i][1] << endl;
            found = true;
            break;
        }
    }
    if (!found) {
        cout << "Номер телефону не нашлось." << endl;
    }
    int index;
    cout << "Введите номер записи для изменение: ";
    cin >> index;
    cout << "Введите  нове Имя: ";
    cin >> name;
    cout << "Введите новый номер телефона: ";
    cin >> phone_num;
    data[index][0] = name;
    data[index][1] = phone_num;
    cout << "Даные успешно изменены." << endl;
    return 0;
}*/

   