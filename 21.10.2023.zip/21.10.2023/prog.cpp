#include "function.h"
#define INTEGER
using namespace std;
int main() {
	const int size = 10;
	Type* arr = new Type[size];
	randArr(arr, size);
	Arr_(arr, size);
	cout << "���: " << 1_Min(arr, size) << endl;
	cout << "����: " << 2_Max(arr, size) << endl;
	sortArray(arr, size);
	Arr_(arr, size);

	editArray(arr, size);
	Arr_(arr, size);

	delete[] arr;

	return 0;
}