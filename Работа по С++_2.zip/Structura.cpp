﻿#include <iostream>

using namespace std;

struct Auto {
	float length; // Довжина
	float landingHeight; // Висота посадки
	float engineVolume; // Об'єм двигуна
	float enginePower; // Потужність двигуна
	float wheelDiameter; // Діаметр коліс
	string color; // Колір
	string gearboxType; // Тип коробки передач
};
void setAutoValues(Auto& auto) {
	cout << "Введіть довжину: ";
	cin >> auto.length;
	cout << "Введіть висоту посадки: ";
	cin >> auto.landingHeight;
	cout << "Введіть об'єм двигуна: ";
	cin >> auto.engineVolume;
	cout << "Введіть потужність двигуна: ";
	cin >> auto.enginePower;
	cout << "Введіть діаметр коліс: ";
	cin >> auto.wheelDiameter;
	cout << "Введіть колір: ";
	cin.ignore(); // Пропускаємо пробіли після введення числа
	getline(cin, auto.color);
	cout << "Введіть тип коробки передач: ";
	getline(cin, auto.gearboxType);
}

void printAutoValues(const Auto& auto) {
	cout << "Меню характеристик" << endl;
	cout << "Довжина: " << auto.length << endl;
	cout << "Висота посадки: " << auto.landingHeight << endl;
	cout << "Об'єм двигуна: " << auto.engineVolume << endl;
	cout << "Потужність двигуна: " << auto.enginePower << endl;
	cout << "Діаметр коліс: " << auto.wheelDiameter << endl;
	cout << "Колір: " << auto.color << endl;
	cout << "Тип коробки передач: " << auto.gearboxType << endl;
}