﻿namespace Shop
{
    class Shop
    {
        public string? Name {  get; set; }
        public string? addres {  get; set; }
        public string? Description { get; set; }
        public string? contact_number {  get; set; }
        public string? email {  get; set; }


        public Shop()
        {

        }

        public Shop(string _Name,string _addres,string _Description,string _contact_number,string _email)
        {
            Name = _Name;
            addres = _addres;
            Description= _Description;
            contact_number = _contact_number;
            email = _email;
        }

        public void choice()
        {
            Console.WriteLine("________________________________________________________________________________");
            Console.WriteLine("Введите название магазина:");
            Name= Console.ReadLine();
            Console.WriteLine("________________________________________________________________________________");
            Console.WriteLine("Введите адрес:");
            addres=Console.ReadLine();
            Console.WriteLine("________________________________________________________________________________");
            Console.WriteLine("Введите описание профиля магазина: ");
            Description = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Введите контактный номер:");
            contact_number= Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Введите email:");
            email= Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________________");
        }
        public void output()
        {
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Название магазина:",Name);
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Адрес:",addres);
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Описание профиля магазина:",Description);
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Контактный номер:",contact_number);
            Console.WriteLine("_________________________________________________________________________________");
            Console.WriteLine("Email:",email);
            Console.WriteLine("_________________________________________________________________________________");
        }




































        static void Main(string[] args)
        {
           
        }
    }
}
