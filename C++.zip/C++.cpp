﻿#include <iostream>
#include <string>
using namespace std;

//1
//#include <algorithm>
//#include <string>
//
//string remove_char_at(string str, int index) {
//if (index < 0 || index >= str.size()) {return str; }
//str.erase(index, 1);
// return str;
//}
 


//2
 //int main_1() {
//    setlocale(LC_ALL, "Russian");
//   
// 
//   char print_2;
//  
//    cout << "Введите букву:" << endl;
//    cin >> print_2;
//    cout << "До изменений:" << endl;
//    char s[] = "HELLO Student";
//    cout << "после:" << endl;
//    cout << s<<endl;
//    char c = print_2;
//    *remove(s, s + strlen(s), c) = '\0';
//    cout << s << endl;
//   
//
//    return 0;
//}

    
//3
//#include <algorithm>
//#include <string>
//
//    string insert_char_at(string str, int index, char p) {
//        if (index < 0 || index > str.size()) { return str; }
//        str.insert(index, 1, p);
//        return str;
//    }

 //4
 /* int main() {
string str;
cout << "Введите рядок: ";
getline(cin, str);
for (int i = 0; i < str.size(); ++i) {
    if (str[i] == '.') {
        str[i] = '!';
    }}
cout << "Новий рядок: " << str << endl;
return 0;}*/
 
  //5  
//int main() {
//    string str;
//    char p;
//    int count = 0;
//    cout << "Введите рядок: ";
//    getline(std::cin, str);
//    cout << "Введите  символ: ";
//    cin >> p;
//    for (int i = 0; i < str.size(); ++i) {
//        if (str[i] == p) {
//            count++;}}
//    cout << "Символ '" << p << "встречается  " << count << "не сколько раз." << std::endl;
//    return 0;
//}
//6
int main() {
    string str;
    int letters = 0, digits = 0, others = 0;
    cout << "Введите рядок: ";
    getline(std::cin, str);   
    for (char ch : str) {
        
        if (std::isalpha(ch)) {
            letters++;
        }
        
        else if (std::isdigit(ch)) {
            digits++;
        }
 
        else {
            others++;
        }
    }
    cout << "Количество букв: " << letters << std::endl;
    cout << "Количество цифр: " << digits << std::endl;
    cout << "Количество других символов: " << others << std::endl;
    return 0;
    //Функция getline в C++ используется для чтения строки
    //символов из входного потока, обычно стандартного ввода (cin), и сохранения ее в строковой переменной. Вот разбивка
}