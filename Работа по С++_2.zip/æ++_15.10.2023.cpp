﻿
#include <iostream>
using namespace std;

struct Complex_number
    double a; // Дійсна частина
    double b; // Мнима частина

   //конструктор
    Complex_number() : a(0), b(0) {}  
    Complex_number double a, double b) : a(a), b(b)
    {

    }

    double new_a() const { return a; }
    void num_a(double a) { this->a = a; }
    double new_b() const { return b; }//Доступ до дійсної та мнимої частин
    void num_b(double b) { this->b = b; }

    // Перевантаження
    friend ostream& operator<<(ostream& os, const Complex_number& c) {
        os << c.a << (c.b >= 0 ? "+" : "") << c.b << "i";
        return os;
    }
};