﻿
#include <iostream>
using namespace std;
int main()
{
    setlocale(LC_ALL, "ru");
    class Pet {
    public:
        Pet(string name) {
            this->name = name;
        }

        string getName() const {
            return name;
        }

        virtual void makeSound() = 0; // метод звука

    protected:
        string name;
    };

    // Собака
    class Dog : public Pet {
    public:
        Dog(string name) : Pet(name) {}

        void makeSound() override {
            cout << name << ": Гав гав гав !";
        }
    };

    // Кошка
    class Cat : public Pet {
    public:
        Cat(string name) : Pet(name) {}

        void makeSound() override {
            cout << name << ": Мяу мяу мяу!";
        }
    };

    class Parrot : public Pet {//Папугай
    public:
        Parrot(string name) : Pet(name) {}

        void makeSound() override {
            cout << name << ": Ки ки ки!";
        }
    };

    int main();
    {
        setlocale(LC_ALL, "ru");
        Dog dog("Шарик");
        Cat cat("Мурка");
        Parrot parrot("Кеша");

        dog.makeSound();
        cat.makeSound();
        parrot.makeSound();

        return 0;
    }
}

