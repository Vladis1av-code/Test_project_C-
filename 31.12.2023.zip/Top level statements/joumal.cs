﻿namespace joumal
{
    class New_joumal
    {

        public string? Name {  get; set; }
        public string ?time { get; set; }  
        public string? Description { get; set; }
        public string ? phone_number { get; set; }
        public string? email {  get; set; }

       public New_joumal()
        {

        }

        public New_joumal(string _Name,string _time,string _Description,string _phone_number,string _email)
        {
            Name = _Name;
            time = _time;
            Description = _Description;
            phone_number=_phone_number;
            email = _email;
        }
        
        public void choice()
        {
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите название журнала:");
             Name=Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите год основание: ");
           time= Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Описание журнала:");
            Description = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("контактный номер телефона:");
            phone_number = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            Console.WriteLine("Введите свой email:");
            email = Console.ReadLine();
            Console.WriteLine("_________________________________________________________________________");
            
        }

        public void Main(string[] args)
        {
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Название журнала:",Name);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Год основание:",time);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Описание:",Description);           
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("Номер телефона:",phone_number);
            Console.WriteLine("___________________________________________________________________________");
            Console.WriteLine("email:",email);

        }

































    }
}
