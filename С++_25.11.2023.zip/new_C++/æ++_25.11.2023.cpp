﻿
#include <vector>
#include <iostream>
using namespace std;
struct Node {
    string car_Number;
    vector<string> breach;
    Node* left;
    Node* right;

    Node(string carNumber) : car_Number(carNumber), left(nullptr), right(nullptr) {}
};

//  квитанції
void insertViolation(Node*& root, string carNumber, string violation) {
    if (root == nullptr) {
        root = new Node(carNumber);
        root->breach.push_back(violation);
        return;
    }
   
    if (root->car_Number == carNumber) {
        root->breach.push_back(violation);
        return;
    }

    if (carNumber < root->car_Number) {
        insertViolation(root->left, carNumber, violation);
    }
    else {
        insertViolation(root->right, carNumber, violation);
    }
}

// База данных
void printDatabase(Node* root) {
    if (root == nullptr) {
        return;
    }
    setlocale(LC_ALL, "ru");
    printDatabase(root->left);
    cout << "Номер машины: " << root->car_Number << endl;
    for (string violation : root->breach) {
        cout << "- " << violation << endl;
    }
    printDatabase(root->right);
}

// Функция по номерам машины
void printByCarNumber(Node* root, string carNumber) {
    setlocale(LC_ALL, "ru");
    if (root == nullptr) {
        cout << "Автомобиль не найден" << endl;
        return;
    }

    if (root->car_Number == carNumber) {
        cout << "Номер машины: " << root->car_Number << endl;
        for (string violation : root->breach) {
            cout << "- " << violation << endl;
        }
        return;
    }

    if (carNumber < root->car_Number) {
        printByCarNumber(root->left, carNumber);
    }
    else {
        printByCarNumber(root->right, carNumber);
    }
}

// Функция по диапозонам  машины
void printByCarNumberRange(Node* root, string minCarNumber, string maxCarNumber) {
    setlocale(LC_ALL, "ru");
    if (root == nullptr) {
        return;
    }

    if (root->car_Number >= minCarNumber && root->car_Number <= maxCarNumber) {
        cout << "Номер машины: " << root->car_Number << endl;
        for (string violation : root->breach) {
            cout << "- " << violation << endl;
        }
    }

    if (root->car_Number < minCarNumber) {
        printByCarNumberRange(root->left, minCarNumber, maxCarNumber);
    }
    else {
        printByCarNumberRange(root->left, minCarNumber, maxCarNumber);
        printByCarNumberRange(root->right, minCarNumber, maxCarNumber);
    }
}

int main() {
    setlocale(LC_ALL, "ru");
    Node* root = nullptr;
    insertViolation(root, "AA1234", "Привышение скорости");
    insertViolation(root, "BB5678", "Привышение скорости"); 
    printDatabase(root);
   printByCarNumber(root, "BB5678");
   printByCarNumberRange(root, "BB5678", "АА5678");

    return 0;
}


