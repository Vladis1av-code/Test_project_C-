#pragma once
#ifndef FUNCTION_H
#define FUNCTION_H
#ifdef INTEGER
typedef int Type;
#elif defined(CHAR)
typedef char Type;
#elif defined(DOUBLE)
typedef double Type;
#endif
void randomFillArray(Type* arr, int size);
void printArray(Type* arr, int size);
Type findMin(Type* arr, int size);
Type findMax(Type* arr, int size);
void sortArray(Type* arr, int size);
void editArray(Type* arr, int size);
#ifdef INTEGER
#define ShowArray ShowArrayInt
#elif defined(CHAR)
#define ShowArray ShowArrayChar
#elif defined(DOUBLE)
#define ShowArray ShowArrayDouble
#endif
#endif