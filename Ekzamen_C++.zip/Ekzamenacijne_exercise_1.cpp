﻿#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstdlib>
#include <direct.h>
#include <vector>
#include <fileapi.h>
using namespace std;
int main()
{
	setlocale(LC_ALL, "ru");
	cout << "______________________________________________________________" << endl;
	cout << "Меню" << endl;
	cout << "1.Показывать содержимое дисков" << endl;
	cout << "2.Создать папку" << endl;
	cout << "3.Создать файл" << endl;
	cout << "4.Удалить папку" << endl;
	cout << "5.Удалить файл" << endl;
	cout << "6.Переименовать папку" << endl;
	cout << "7.Переименовать файл" << endl;
	cout << "8.Копировать папку" << endl;
	cout << "9.Копировать файл" << endl;
	cout << "10.Посчитать размер папки(bit)" << endl;
	cout << "11.Посчитать размер файла(bit)" << endl;
	cout << "12.Выход" << endl;
	int choice;
	cout << "Введите свою цифру:";
	cin >> choice;
	cout << "______________________________________________________________" << endl;


	if (choice == 1)
	{
		system("DIR"); 
		return 0;
	}
	else if (choice == 2)
	{
		int createDescktopDir(const char* dname) {			
			const char* env_homepath = getenv("Error");
			string desctoppath = string(env_homedrive) + env_homepath + "\\Desktop\\" + dname;
			return _mkdir(desctoppath.c_str());
		}
	
	}
	else if (choice == 3)
	{
		fstream file("file.txt");
		file.open("file.txt");
		cout << "Файл успешно создан" << endl;
		file.close();
	}
	else if (choice == 4)
	{
		if (RemoveDirectory("folder")) {
			cout << "Папка удалена!" << std::endl;
		}
		else {
			cout << "Ошибка удаления папки." << std::endl;
		}

	}
	else if (choice == 5)
	{
		if (remove("file.txt")==0)
		{
			cout << "Файл успешно удален!" << endl;
		}
		else
		{
			cout << "Файл не был удален" << endl;
		}
	}
	else if (choice == 6)
	{
		filesystem::path old_path("folder");
		filesystem::path new_path("new_folder");
		if (filesystem::exists(old_path))
		{
			filesystem::rename(old_path, new_path);
			cout << "Папка переименована!" << endl;
		}
		else {
			cout << "Папка не найдена " << old_path << endl;
		}
	}
	else if (choice == 7)
	{
		filesystem::path old_path("file.txt");
		filesystem::path new_path("new_file.txt");
		if (filesystem::exists(old_path))
		{
			filesystem::rename(old_path, new_path);
			cout << "Папка переименована!" << endl;
		}
		else {
			cout << "Папка не найдена " << old_path << endl;
		}
	}
	else if (choice == 8)
	{
		ifstream source_file("folder");
		ofstream dest_file("'С:Microsoft'");//путь где файл находится

		if (source_file.is_open() && dest_file.is_open())
		{
			char ch;
			while (source_file.get(ch))
			{
				dest_file.put(ch);
			}
			source_file.close();
			dest_file.close();
			cout << "Папка скопирован в диск C!" << endl;
		}
		else {
			cout << "Ошибка открытия папки." << endl;
		}
	}
	else if (choice == 9)
	{
		ifstream source_file("file.txt");
		ofstream dest_file("'С:Microsoft'");//путь где файл находится

		if (source_file.is_open() && dest_file.is_open()) 
		{
			char ch;
			while (source_file.get(ch)) 
			{
				dest_file.put(ch);
			}
			source_file.close();
			dest_file.close();
			cout << "Файл скопирован в диск C!" << endl;
		}
		else {
			cout << "Ошибка открытия файлов." << endl;
		}
	}
	else if (choice == 10)
	{
		ifstream fin("file.txt", ifstream::in);
		if (!fin.is_open()) {
			return false;
		}
		fin.seekg(0, fin.end);
		streamsize size = fin.tellg();
		fin.seekg(0, ios::beg);

		vector<char> data(size, 0);
		fin.read(&data[0], size);
	}
	else if (choice == 11)
	{
		ifstream fin("folder", ifstream::in);
		if (!fin.is_open()) {
			return false;
		}
		fin.seekg(0, fin.end);
		streamsize size = fin.tellg();
		fin.seekg(0, ios::beg);

		vector<char> data(size, 0);
		fin.read(&data[0], size);
		}
	}
	else if (choice == 12)
	{
		return 0;
	}
	return 0;
}


