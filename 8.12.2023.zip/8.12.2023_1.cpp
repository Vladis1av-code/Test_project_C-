﻿
#include <memory>
#include <iostream>
using namespace std;

class User {
public:
    User(const string& name, int age) : name(name), age(age) {}
    ~User() { cout << "User " << name << " destroyed" << endl; }

    const string& getName() const { return name; }
    int getAge() const { return age; }

private:
   string name;
    int age;
};

class UserPtr {
public:
    explicit UserPtr(User* user) : ptr(user) {}

    UserPtr& operator=(UserPtr&& rhs) noexcept {
        if (this != &rhs) {
            delete ptr;
            ptr = rhs.ptr;
            rhs.ptr = nullptr;
        }
        return *this;
    }

    User* operator->() { return ptr; }

    const User* operator->() const { return ptr; }

    User& operator*() { return *ptr; }

    const User& operator*() const { return *ptr; }

    User* get() { return ptr; }

    const User* get() const { return ptr; }

    bool unique() const { return ptr == nullptr; }

private:
    User* ptr;
};
