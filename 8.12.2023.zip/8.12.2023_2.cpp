#include <memory>
#include <string>
#include <iostream>
using namespace std;
class User {
    
public:
   
    User(const string& name, int age) : name(name), age(age) {}
    ~User() { cout << "������������ " << name << " ������" << endl; }

    const string& getName() const { return name; }
    int getAge() const { return age; }

private:
    string name;
    int age;
};

class SharedUserPtr {
public:
    explicit SharedUserPtr(User* user) : ptr(user), refCount(user ? new int(1) : nullptr) {}

    SharedUserPtr(const SharedUserPtr& rhs) : ptr(rhs.ptr), refCount(rhs.refCount) {
        if (refCount) {
            ++*refCount;
        }
    }

    SharedUserPtr& operator=(const SharedUserPtr& rhs) {
        if (this != &rhs) {
            release();
            ptr = rhs.ptr;
            refCount = rhs.refCount;
        }
        return *this;
    }

    ~SharedUserPtr() { release(); }

    User* operator->() { return ptr; }

    const User* operator->() const { return ptr; }

    User& operator*() { return *ptr; }

    const User& operator*() const { return *ptr; }

    User* get() { return ptr; }

    const User* get() const { return ptr; }

    size_t use_count() const { return *refCount; }

private:
    void release() {
        if (ptr && -- * refCount == 0) {
            delete ptr;
            delete refCount;
            ptr = nullptr;
            refCount = nullptr;
        }
    }

    User* ptr;
    int* refCount;
};