﻿#include <iostream>
#include <vector>
#include <random>
using namespace std;
struct Passenger{
  double arrivalTime; // Время прибытие на остановку
  double waitingTime; // Время ожиданние
};

struct Shuttle {
	double arrivalTime; // Время появление на остановку
	int freeSeats; // Количество пустых мест
};

void Stop(int numIterations, double* avgWaitingTime, double* sufficientInterval, vector<Passenger>& passengers, vector<Shuttle>& shuttles, double minArrivalTimePassengers, double maxArrivalTimePassengers, double minArrivalTimeShuttles, double maxArrivalTimeShuttles, int minFreeSeats, int maxFreeSeats, int maxPeopleAtStop, bool isFinalStop) 
{
	double totalWaitingTime = 0;
	int maxPeopleOnStop = 0;

	//Итерация
	for (int i = 0; i < numIterations; ++i) {

		//Время
		double currentTime = generate_Number(0, 24 * 60 * 60);//День\Часы\Минуты\Секунды

		// Пасажиры
		while (true) {
			double arrivalTimePassenger = generate_Number(minArrivalTimePassengers, maxArrivalTimePassengers);
			if (arrivalTimePassenger <= currentTime) {
				Passenger passenger;
				passenger.arrivalTime = arrivalTimePassenger;
				passenger.waitingTime = 0;
				passengers.push_back(passenger);
			}
			else {
				break;
			}
		}

		double generate_Number(double min, double max) 
		{
			random_device rd;

			mt19937 generator(rd());

			uniform_real_distribution<double> distribution(min, max);

			return distribution(generator);
		}
		void Stop(int numIterations, double* avgWaitingTime, double* sufficientInterval, vector);
		while (true) 
		{
			double arrivalTimePassenger = generate_Number(minArrivalTimePassengers, maxArrivalTimePassengers);
			if (arrivalTimePassenger <= currentTime) 
			{
				Passenger passenger;
				passenger.arrivalTime = arrivalTimePassenger;
				passenger.waitingTime = 0;
				passengers.push_back(passenger);
			}
			else
			{
				break;
			}
		}
		//Маршрутки
		while (true) 
		{
			double arrivalTimeShuttle = generate_Number(minArrivalTimeShuttles, maxArrivalTimeShuttles);
			if (arrivalTimeShuttle <= currentTime) 
			{
				Shuttle shuttle;
				shuttle.arrivalTime = arrivalTimeShuttle;
				shuttle.freeSeats = generate_Number(minFreeSeats, maxFreeSeats);
				shuttles.push_back(shuttle);
			}
			else
			{
				break;
			}
		}
		// Обработка пасажиров
		for (int j = 0; j < passengers.size(); ++j) {
			Passenger& passenger = passengers[j];
			for (int k = 0; k < shuttles.size(); ++k) {
				Shuttle& shuttle = shuttles[k];
				if (shuttle.arrivalTime <= currentTime && shuttle.freeSeats > 0) {					
					passenger.waitingTime = currentTime - passenger.arrivalTime;
					totalWaitingTime += passenger.waitingTime;
					shuttle.freeSeats--;
					passengers.erase(passengers.begin() + j);
					j--;
					break;
				}
			}
		}
	
		//Подсчет максимальных людей
		int peopleAtStop = passengers.size();
		for (const Shuttle& shuttle : shuttles) 
		{
			if (shuttle.arrivalTime <= currentTime) 
			{
				peopleAtStop += shuttle.freeSeats;
			}
		}
		maxPeopleOnStop = max(maxPeopleOnStop, peopleAtStop);
	}
	*avgWaitingTime = totalWaitingTime / passengers.size();
	*sufficientInterval = (double)maxPeopleAtStop / (minArrivalTimeShuttles - maxArrivalTimeShuttles);
}

int main()
{
	setlocale(LC_ALL, "ru");
	int num_Iterations;

	cout << "Введите количество итераций: ";
	cin >> num_Iterations;

	double min_Arrival_Time_Passengers, max_Arrival_Time_Passengers;

	cout << "Введите минимальное время между прибывание пасажиров (в секундах): ";
	cin >> min_Arrival_Time_Passengers;

	cout << "Введите максимальное время между прибывание пасажиров (в секундах):";
	cin >> max_Arrival_Time_Passengers;

}

//Passenger для представлення інформації про пасажира, наприклад, час його прибуття на зупинку, час очікування маршрутки, номер квитка тощо.
//*sufficientInterval- в C++ використовується для зберігання мінімального інтервалу часу
