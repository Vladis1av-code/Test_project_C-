﻿#include <iostream>
#include <cmath>
#include <vector>
using namespace std;
class Equation {
public:
    // Віртуальна функція для знаходження коренів (буде реалізована в похідних класах)
    virtual vector<double> solve() const = 0;

    // Функція для виведення рівняння на екран
    virtual void print() const = 0;

    // Конструктор за замовчуванням (може бути додано інші конструктори)
    Equation() = default;
};

class LinearEquation : public Equation {
private:
    double a; // Коефіцієнт при x
    double b; // Вільний член

public:
    // Конструктор
    LinearEquation(double a_, double b_) : a(a_), b(b_) {}

    // Функція для знаходження коренів
    vector<double> solve() const override {
        vector<double> roots;
        if (a == 0) {
            // Рівняння не має коренів, якщо a = 0
        }
        else {
            roots.push_back(-b / a);
        }
        return roots;
    }

    // Функція для виведення рівняння на екран
    void print() const override {
        cout << a << "x" << (b >= 0 ? "+" : "") << b << " = 0" << endl;
    }
};

class QuadraticEquation : public Equation {
private:
    double a; // Коефіцієнт при x^2
    double b; // Коефіцієнт при x
    double c; // Вільний член

public:
    // Конструктор
    QuadraticEquation(double a_, double b_, double c_) : a(a_), b(b_), c(c_) {}

    // Функція для знаходження коренів
    vector<double> solve() const override {
        vector<double> roots;
        double discriminant = b * b - 4 * a * c;

        if (discriminant < 0) {
            // Рівняння не має дійсних коренів
        }
        else if (discriminant == 0) {
            roots.push_back(-b / (2 * a)); // Один корінь
        }
        else {
            double sqrtD = sqrt(discriminant);
            roots.push_back((-b + sqrtD) / (2 * a));
            roots.push_back((-b - sqrtD) / (2 * a)); // Два корені
        }
        return roots;
    }

    // Функція для виведення рівняння на екран
    void print() const override {
        cout << a << "x^2" << (b >= 0 ? "+" : "") << b << "x" << (c >= 0 ? "+" : "") << c << " = 0" << endl;
    }
};
int main() {
    setlocale(LC_ALL, "ru");
    // Створення об'єктів
    LinearEquation le(2, 3);
    QuadraticEquation qe(1, 4, 3);

    // Виведення рівнянь та знаходження коренів
    cout << "Лінійне рівняння: ";
    le.print();
    cout << "Корінь: ";
    for (double root : le.solve()) {
        cout << root << " ";
    }
    cout << endl;

    cout << "Квадратне рівняння: ";
    qe.print();
    cout << "Корені: ";
    for (double root : qe.solve()) {
        cout << root << " ";
    }
    cout << endl;

    return 0;
}
