﻿#include <iostream>
#include <fstream>
#include <vector>
using namespace std;

class Shape {
public:
   
    virtual void Show() = 0;

    
    virtual void Save(const string& filename) = 0;

   
    virtual void Load(const string& filename) = 0;
};
class Square : public Shape {
private:
    double x, y; // 
    double side; // 

public:
    Square(double x, double y, double side) : x(x), y(y), side(side) {}

    void Show() override {
        cout << "Квадрат: " << "x = " << x << ", y = " << y << ", сторона = " << side << endl;
    }

    void Save(const string& filename) override {
        ofstream fout(filename);
        fout << "Square" << endl;
        fout << x << " " << y << " " << side << endl;
        fout.close();
    }

    void Load(const string& filename) override {
        ifstream fin(filename);
        if (fin.is_open()) {
            string type;
            fin >> type;
            if (type == "Square") {
                fin >> x >> y >> side;
            }
            fin.close();
        }
        else {
            cout << "Error" << filename << endl;
        }
    }
};
class Rectangle : public Shape {
private:
    double x, y; 
    double width, height; // ширина и высота

public:
    Rectangle(double x, double y, double width, double height) : x(x), y(y), width(width), height(height) {}

    void Show() override {
        cout << "Прямокутник: " << "x = " << x << ", y = " << y << ", ширина = " << width << ", висота = " << height << endl;
    }

    void Save(const string& filename) override {
        ofstream fout(filename);
        fout << "Rectangle" << endl;
        fout << x << " " << y << " " << width << " " << height << endl;
        fout.close();
    }

    void Load(const string& filename) override {
        ifstream fin(filename);
        if (fin.is_open()) {
            string type;
            fin >> type;
            if (type == "Rectangle") {
                fin >> x >> y >> width >> height;
            }
            fin.close();
        }
        else {
            cout << "Error " << filename << endl;
        }
    }
};
class Circle : public Shape {
private:
    double x, y; // Координати центру
    double radius; // Радіус

public:
    Circle(double x, double y, double radius) : x(x), y(y), radius(radius) {}

    void Show() override {
        cout << "Круг: " << "x = " << x << ", y = " << y << ", радиус = " << radius;
        // Опис абстрактного класу Shape(залишається без змін)
        class Shape {
        public:
            virtual void Show() = 0;
            virtual void Save(const string& filename) = 0;
            virtual void Load(const string& filename) = 0;
        };

        // Опис похідних класів Square, Rectangle та Circle (без змін)

        // Функція для збереження масиву фігур у файл
        void SaveShapesToFile(vector<Shape*>&shapes, const string & filename) {
            ofstream fout(filename);
            if (fout.is_open()) {
                for (Shape* shape : shapes) {
                    shape->Save(filename); // Збереження кожної фігури окремо
                }
                fout.close();
            }
            else {
                cout << "Error " << filename << endl;
            }
        }

        // Функція для завантаження масиву фігур з файлу
        vector<Shape*> LoadShapesFromFile(const string & filename) {
            vector<Shape*> shapes;
            ifstream fin(filename);
            if (fin.is_open()) {
                string type;
                while (fin >> type) {
                    if (type == "Square") {
                        double x, y, side;
                        fin >> x >> y >> side;
                        shapes.push_back(new Square(x, y, side));
                    }
                    else if (type == "Rectangle") {
                        double x, y, width, height;
                        fin >> x >> y >> width >> height;
                        shapes.push_back(new Rectangle(x, y, width, height));
                    }
                    else if (type == "Circle") {
                        double x, y, radius;
                        fin >> x >> y >> radius;
                        shapes.push_back(new Circle(x, y, radius));
                    }
                }
                fin.close();
            }
            else {
                cout << "Error" << filename << endl;
            }
            return shapes;
        }

        int main() {
            // Создавание фигур
            vector<Shape*> shapes;
            shapes.push_back(new Square(10, 20, 5));
            shapes.push_back(new Rectangle(30, 40, 15, 10));
            shapes.push_back(new Circle(50, 60, 7));

            // Збереження масиву фігур у файл
            string filename = "shapes.dat";
            SaveShapesToFile(shapes, filename);

            // Завантаження масиву фігур з файлу
            vector<Shape*> loadedShapes = LoadShapesFromFile(filename);

            // Виведення інформації про кожну з фігур
            cout << "Фігури з файлу:" << endl;
            for (Shape* shape : loadedShapes) {
                shape->Show();
            }

            return 0;
        }
    }
};
