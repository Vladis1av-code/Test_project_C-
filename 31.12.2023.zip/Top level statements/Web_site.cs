﻿using System.Collections.Specialized;
using System.Net;
using System.Security.Cryptography.X509Certificates;

namespace Web_site
{
     class Web_site
    {
        public string? Name { get; set; }

        public string? Url { get; set; } 

        public string? description { get; set; }

        public string? ip_address {get;set;}

        public Web_site()
        {

        }

        public Web_site(string _Name,string _Url,string _description,string _ip_address)
        {
            Name=_Name;
            Url=_Url;
            description=_description;
            ip_address=_ip_address;

        }
      
        public void choice()
        {
            Console.WriteLine("_____________________________________________________________________________");
            Console.Write("Введите название сайта:");
            Name = Console.ReadLine();
            Console.WriteLine("_____________________________________________________________________________");
            Console.Write("Введите Url ссылку:");
            Url = Console.ReadLine();
            Console.WriteLine("_____________________________________________________________________________");
            Console.Write("Введите описание сайта:");
            description = Console.ReadLine();
            Console.WriteLine("_____________________________________________________________________________");
            Console.Write("Введите ip-адрес сайта:");
            ip_address = Console.ReadLine();
            Console.WriteLine("_____________________________________________________________________________");
        }
        public void Output()
        {
            Console.WriteLine("Название сайта:",Name);
            Console.WriteLine("_____________________________________________________________________________");
            Console.WriteLine("Url сайта:",Url);
            Console.WriteLine("_____________________________________________________________________________");
            Console.WriteLine("Описание сайта:",description);
            Console.WriteLine("_____________________________________________________________________________");
            Console.WriteLine("ip-адрес сайта:",ip_address);
            Console.WriteLine("_____________________________________________________________________________");
        }


    }

  










}


