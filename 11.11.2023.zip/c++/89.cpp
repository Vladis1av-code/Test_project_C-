﻿#include <iostream>
#include <string>
using namespace std;
bool checking(string str)
{
    stack<char> s;
    for (char c : str) {
     

        if (c == '(' ) {
            s.push(c);
        }
        else if (c == ')' ) {
            if (s.empty() ||s.top() != c - 2) return false;
            s.pop();
        }
//________________________________________________________________
        else if ( c == '[' ) {
            s.push(c);
        }
        else if ( c == ']' ) {
            if (s.empty() || s.top() != c - 2) return false;
            s.pop();
        } 
//_________________________________________________________________
        else if (c == '{') {
            s.push(c);
        }
        else if (c == '}') {
            if (s.empty() || s.top() != c - 2) return false;
            s.pop();
        }
    }
    return s.empty();
}
//stack-використовується для роботи зі стеками в C++. Стек - це структура даних LIFO (Last-In-First-Out), де останній доданий елемент є першим, який буде видалений.
//push(x) : Додає елемент x до вершини стека.
//pop() : Видаляє та повертає елемент з вершини стека.
//top() : Повертає елемент з вершини стека, не видаляючи його.
//empty() : Перевіряє, чи стек порожній.
//size() : Повертає розмір стека.

int main() {
    setlocale(LC_ALL, "Uk");
    string str;
    cout << "Введіть рядок символів: ";
    getline(cin, str);

    if (checking(str)) {
        cout << "Рядок символів допустимий." << endl;
    }
    else {
        cout << "Рядок символів недопустимий!" << endl;
    }
    return 0;
}
